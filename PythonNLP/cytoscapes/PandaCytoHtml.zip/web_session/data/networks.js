var networks = {"PandaNetworkData.tsv": {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.10.3",
  "target_cytoscapejs_version" : "~2.1",
  "data" : {
    "shared_name" : "PandaNetworkData.tsv",
    "name" : "PandaNetworkData.tsv",
    "SUID" : 155,
    "__Annotations" : [ ],
    "selected" : true
  },
  "elements" : {
    "nodes" : [ {
      "data" : {
        "id" : "381",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Stress" : 0,
        "shared_name" : "surprised",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "surprised",
        "SelfLoops" : 0,
        "SUID" : 381,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 4.0
      },
      "position" : {
        "x" : 93.59374999999977,
        "y" : 95.67187499999997
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "376",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Stress" : 0,
        "shared_name" : "unreal",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "unreal",
        "SelfLoops" : 0,
        "SUID" : 376,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 4.0
      },
      "position" : {
        "x" : 183.59374999999977,
        "y" : 95.67187499999997
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "371",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Stress" : 0,
        "shared_name" : "valuable",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "valuable",
        "SelfLoops" : 0,
        "SUID" : 371,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 4.0
      },
      "position" : {
        "x" : 153.59374999999977,
        "y" : 95.67187499999997
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "365",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "LPInTheEnd",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 4,
        "Indegree" : 4,
        "synsetCount" : 4,
        "name" : "LPInTheEnd",
        "SelfLoops" : 0,
        "SUID" : 365,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 1.0
      },
      "position" : {
        "x" : 138.59374999999977,
        "y" : 43.67187499999997
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "363",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Stress" : 0,
        "shared_name" : "due",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "due",
        "SelfLoops" : 0,
        "SUID" : 363,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 4.0
      },
      "position" : {
        "x" : 123.59374999999977,
        "y" : 95.67187499999997
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "356",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Stress" : 0,
        "shared_name" : "natural",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "natural",
        "SelfLoops" : 0,
        "SUID" : 356,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 8.0
      },
      "position" : {
        "x" : -52.40625000000023,
        "y" : -14.328125000000028
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "351",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Stress" : 0,
        "shared_name" : "worth",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "worth",
        "SelfLoops" : 0,
        "SUID" : 351,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 8.0
      },
      "position" : {
        "x" : -112.40625000000023,
        "y" : -14.328125000000028
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "340",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Stress" : 0,
        "shared_name" : "ritual",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "ritual",
        "SelfLoops" : 0,
        "SUID" : 340,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 8.0
      },
      "position" : {
        "x" : 37.59374999999977,
        "y" : -14.328125000000028
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "333",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Stress" : 0,
        "shared_name" : "fast",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 3,
        "Indegree" : 0,
        "name" : "fast",
        "SelfLoops" : 0,
        "SUID" : 333,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 8.0
      },
      "position" : {
        "x" : -22.406250000000227,
        "y" : -14.328125000000028
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "328",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Stress" : 0,
        "shared_name" : "dedicated",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 2,
        "Indegree" : 0,
        "name" : "dedicated",
        "SelfLoops" : 0,
        "SUID" : 328,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 8.0
      },
      "position" : {
        "x" : 7.593749999999773,
        "y" : -14.328125000000028
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "323",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Stress" : 0,
        "shared_name" : "More",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 2,
        "Indegree" : 0,
        "name" : "More",
        "SelfLoops" : 0,
        "SUID" : 323,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 8.0
      },
      "position" : {
        "x" : -82.40625000000023,
        "y" : -14.328125000000028
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "318",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Stress" : 0,
        "shared_name" : "clear",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 2,
        "Indegree" : 0,
        "name" : "clear",
        "SelfLoops" : 0,
        "SUID" : 318,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 8.0
      },
      "position" : {
        "x" : -142.40625000000023,
        "y" : -14.328125000000028
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "312",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 4,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "MMasterPup",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 13,
        "Indegree" : 13,
        "synsetCount" : 15,
        "name" : "MMasterPup",
        "SelfLoops" : 0,
        "SUID" : 312,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 1.0
      },
      "position" : {
        "x" : -37.40625000000023,
        "y" : -70.82812500000003
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "310",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Stress" : 0,
        "shared_name" : "dark",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "dark",
        "SelfLoops" : 0,
        "SUID" : 310,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 8.0
      },
      "position" : {
        "x" : 67.59374999999977,
        "y" : -14.328125000000028
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "300",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "GDWake",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 3,
        "Indegree" : 3,
        "synsetCount" : 8,
        "name" : "GDWake",
        "SelfLoops" : 0,
        "SUID" : 300,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 1.0
      },
      "position" : {
        "x" : 241.09374999999977,
        "y" : 93.17187499999997
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "298",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Stress" : 0,
        "shared_name" : "innocent",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 3,
        "Indegree" : 0,
        "name" : "innocent",
        "SelfLoops" : 0,
        "SUID" : 298,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 1.0
      },
      "position" : {
        "x" : 241.09374999999977,
        "y" : 41.67187499999997
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "285",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Stress" : 0,
        "shared_name" : "scar",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "scar",
        "SelfLoops" : 0,
        "SUID" : 285,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 7.0
      },
      "position" : {
        "x" : -142.40625000000023,
        "y" : -133.32812500000003
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "274",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Stress" : 0,
        "shared_name" : "sweet",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "sweet",
        "SelfLoops" : 0,
        "SUID" : 274,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 7.0
      },
      "position" : {
        "x" : 37.59374999999977,
        "y" : -133.32812500000003
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "269",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Stress" : 0,
        "shared_name" : "broken",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "broken",
        "SelfLoops" : 0,
        "SUID" : 269,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 7.0
      },
      "position" : {
        "x" : 7.593749999999773,
        "y" : -133.32812500000003
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "260",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Stress" : 0,
        "shared_name" : "scarlet",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "scarlet",
        "SelfLoops" : 0,
        "SUID" : 260,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 7.0
      },
      "position" : {
        "x" : -22.406250000000227,
        "y" : -133.32812500000003
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "255",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Stress" : 0,
        "shared_name" : "southern",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "southern",
        "SelfLoops" : 0,
        "SUID" : 255,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 7.0
      },
      "position" : {
        "x" : -112.40625000000023,
        "y" : -133.32812500000003
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "242",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 13,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Stress" : 0,
        "shared_name" : "lonely",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 13,
        "Indegree" : 0,
        "name" : "lonely",
        "SelfLoops" : 0,
        "SUID" : 242,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 7.0
      },
      "position" : {
        "x" : -52.40625000000023,
        "y" : -133.32812500000003
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "236",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 2,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "RHCPScarTis",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 20,
        "Indegree" : 20,
        "synsetCount" : 4,
        "name" : "RHCPScarTis",
        "SelfLoops" : 0,
        "SUID" : 236,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 1.0
      },
      "position" : {
        "x" : -52.40625000000023,
        "y" : -193.32812500000003
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "234",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Stress" : 0,
        "shared_name" : "sarcastic",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 2,
        "Indegree" : 0,
        "name" : "sarcastic",
        "SelfLoops" : 0,
        "SUID" : 234,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 7.0
      },
      "position" : {
        "x" : -82.40625000000023,
        "y" : -133.32812500000003
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "227",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Stress" : 0,
        "shared_name" : "free",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "free",
        "SelfLoops" : 0,
        "SUID" : 227,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 7.0
      },
      "position" : {
        "x" : -82.40625000000023,
        "y" : 100.67187499999997
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "222",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Stress" : 0,
        "shared_name" : "single",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "single",
        "SelfLoops" : 0,
        "SUID" : 222,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 7.0
      },
      "position" : {
        "x" : -142.40625000000023,
        "y" : 100.67187499999997
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "217",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Stress" : 0,
        "shared_name" : "more",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "more",
        "SelfLoops" : 0,
        "SUID" : 217,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 7.0
      },
      "position" : {
        "x" : 37.59374999999977,
        "y" : 100.67187499999997
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "212",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Stress" : 0,
        "shared_name" : "last",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "last",
        "SelfLoops" : 0,
        "SUID" : 212,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 7.0
      },
      "position" : {
        "x" : 7.593749999999773,
        "y" : 100.67187499999997
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "205",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Stress" : 0,
        "shared_name" : "indecent",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 3,
        "Indegree" : 0,
        "name" : "indecent",
        "SelfLoops" : 0,
        "SUID" : 205,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 7.0
      },
      "position" : {
        "x" : -52.40625000000023,
        "y" : 100.67187499999997
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "200",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Stress" : 0,
        "shared_name" : "adolescent",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "adolescent",
        "SelfLoops" : 0,
        "SUID" : 200,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 7.0
      },
      "position" : {
        "x" : -22.406250000000227,
        "y" : 100.67187499999997
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "185",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "FFMonkeyWren",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 9,
        "Indegree" : 9,
        "synsetCount" : 3,
        "name" : "FFMonkeyWren",
        "SelfLoops" : 0,
        "SUID" : 185,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 1.0
      },
      "position" : {
        "x" : -52.40625000000023,
        "y" : 46.17187499999997
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "183",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Stress" : 0,
        "shared_name" : "much",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "much",
        "SelfLoops" : 0,
        "SUID" : 183,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 7.0
      },
      "position" : {
        "x" : -112.40625000000023,
        "y" : 100.67187499999997
      },
      "selected" : false
    } ],
    "edges" : [ {
      "data" : {
        "id" : "384",
        "source" : "381",
        "target" : "365",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "surprised (interacts with) LPInTheEnd",
        "shared_interaction" : "interacts with",
        "name" : "surprised (interacts with) LPInTheEnd",
        "interaction" : "interacts with",
        "SUID" : 384,
        "BEND_MAP_ID" : 384,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "379",
        "source" : "376",
        "target" : "365",
        "EdgeBetweenness" : 5.0,
        "shared_name" : "unreal (interacts with) LPInTheEnd",
        "shared_interaction" : "interacts with",
        "name" : "unreal (interacts with) LPInTheEnd",
        "interaction" : "interacts with",
        "SUID" : 379,
        "BEND_MAP_ID" : 379,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "374",
        "source" : "371",
        "target" : "365",
        "EdgeBetweenness" : 4.0,
        "shared_name" : "valuable (interacts with) LPInTheEnd",
        "shared_interaction" : "interacts with",
        "name" : "valuable (interacts with) LPInTheEnd",
        "interaction" : "interacts with",
        "SUID" : 374,
        "BEND_MAP_ID" : 374,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "369",
        "source" : "363",
        "target" : "365",
        "EdgeBetweenness" : 3.0,
        "shared_name" : "due (interacts with) LPInTheEnd",
        "shared_interaction" : "interacts with",
        "name" : "due (interacts with) LPInTheEnd",
        "interaction" : "interacts with",
        "SUID" : 369,
        "BEND_MAP_ID" : 369,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "359",
        "source" : "356",
        "target" : "312",
        "EdgeBetweenness" : 7.0,
        "shared_name" : "natural (interacts with) MMasterPup",
        "shared_interaction" : "interacts with",
        "name" : "natural (interacts with) MMasterPup",
        "interaction" : "interacts with",
        "SUID" : 359,
        "BEND_MAP_ID" : 359,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "354",
        "source" : "351",
        "target" : "312",
        "EdgeBetweenness" : 9.0,
        "shared_name" : "worth (interacts with) MMasterPup",
        "shared_interaction" : "interacts with",
        "name" : "worth (interacts with) MMasterPup",
        "interaction" : "interacts with",
        "SUID" : 354,
        "BEND_MAP_ID" : 354,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "343",
        "source" : "340",
        "target" : "312",
        "EdgeBetweenness" : 6.0,
        "shared_name" : "ritual (interacts with) MMasterPup",
        "shared_interaction" : "interacts with",
        "name" : "ritual (interacts with) MMasterPup",
        "interaction" : "interacts with",
        "SUID" : 343,
        "BEND_MAP_ID" : 343,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "361",
        "source" : "333",
        "target" : "312",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "fast (interacts with) MMasterPup",
        "shared_interaction" : "interacts with",
        "name" : "fast (interacts with) MMasterPup",
        "interaction" : "interacts with",
        "SUID" : 361,
        "BEND_MAP_ID" : 361,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "349",
        "source" : "333",
        "target" : "312",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "fast (interacts with) MMasterPup",
        "shared_interaction" : "interacts with",
        "name" : "fast (interacts with) MMasterPup",
        "interaction" : "interacts with",
        "SUID" : 349,
        "BEND_MAP_ID" : 349,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "336",
        "source" : "333",
        "target" : "312",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "fast (interacts with) MMasterPup",
        "shared_interaction" : "interacts with",
        "name" : "fast (interacts with) MMasterPup",
        "interaction" : "interacts with",
        "SUID" : 336,
        "BEND_MAP_ID" : 336,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "347",
        "source" : "328",
        "target" : "312",
        "EdgeBetweenness" : 3.0,
        "shared_name" : "dedicated (interacts with) MMasterPup",
        "shared_interaction" : "interacts with",
        "name" : "dedicated (interacts with) MMasterPup",
        "interaction" : "interacts with",
        "SUID" : 347,
        "BEND_MAP_ID" : 347,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "331",
        "source" : "328",
        "target" : "312",
        "EdgeBetweenness" : 3.0,
        "shared_name" : "dedicated (interacts with) MMasterPup",
        "shared_interaction" : "interacts with",
        "name" : "dedicated (interacts with) MMasterPup",
        "interaction" : "interacts with",
        "SUID" : 331,
        "BEND_MAP_ID" : 331,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "345",
        "source" : "323",
        "target" : "312",
        "EdgeBetweenness" : 8.0,
        "shared_name" : "More (interacts with) MMasterPup",
        "shared_interaction" : "interacts with",
        "name" : "More (interacts with) MMasterPup",
        "interaction" : "interacts with",
        "SUID" : 345,
        "BEND_MAP_ID" : 345,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "326",
        "source" : "323",
        "target" : "312",
        "EdgeBetweenness" : 8.0,
        "shared_name" : "More (interacts with) MMasterPup",
        "shared_interaction" : "interacts with",
        "name" : "More (interacts with) MMasterPup",
        "interaction" : "interacts with",
        "SUID" : 326,
        "BEND_MAP_ID" : 326,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "338",
        "source" : "318",
        "target" : "312",
        "EdgeBetweenness" : 1.0,
        "shared_name" : "clear (interacts with) MMasterPup",
        "shared_interaction" : "interacts with",
        "name" : "clear (interacts with) MMasterPup",
        "interaction" : "interacts with",
        "SUID" : 338,
        "BEND_MAP_ID" : 338,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "321",
        "source" : "318",
        "target" : "312",
        "EdgeBetweenness" : 1.0,
        "shared_name" : "clear (interacts with) MMasterPup",
        "shared_interaction" : "interacts with",
        "name" : "clear (interacts with) MMasterPup",
        "interaction" : "interacts with",
        "SUID" : 321,
        "BEND_MAP_ID" : 321,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "316",
        "source" : "310",
        "target" : "312",
        "EdgeBetweenness" : 5.0,
        "shared_name" : "dark (interacts with) MMasterPup",
        "shared_interaction" : "interacts with",
        "name" : "dark (interacts with) MMasterPup",
        "interaction" : "interacts with",
        "SUID" : 316,
        "BEND_MAP_ID" : 316,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "308",
        "source" : "298",
        "target" : "300",
        "EdgeBetweenness" : 1.0,
        "shared_name" : "innocent (interacts with) GDWake",
        "shared_interaction" : "interacts with",
        "name" : "innocent (interacts with) GDWake",
        "interaction" : "interacts with",
        "SUID" : 308,
        "BEND_MAP_ID" : 308,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "306",
        "source" : "298",
        "target" : "300",
        "EdgeBetweenness" : 1.0,
        "shared_name" : "innocent (interacts with) GDWake",
        "shared_interaction" : "interacts with",
        "name" : "innocent (interacts with) GDWake",
        "interaction" : "interacts with",
        "SUID" : 306,
        "BEND_MAP_ID" : 306,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "304",
        "source" : "298",
        "target" : "300",
        "EdgeBetweenness" : 1.0,
        "shared_name" : "innocent (interacts with) GDWake",
        "shared_interaction" : "interacts with",
        "name" : "innocent (interacts with) GDWake",
        "interaction" : "interacts with",
        "SUID" : 304,
        "BEND_MAP_ID" : 304,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "288",
        "source" : "285",
        "target" : "236",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "scar (interacts with) RHCPScarTis",
        "shared_interaction" : "interacts with",
        "name" : "scar (interacts with) RHCPScarTis",
        "interaction" : "interacts with",
        "SUID" : 288,
        "BEND_MAP_ID" : 288,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "277",
        "source" : "274",
        "target" : "236",
        "EdgeBetweenness" : 6.0,
        "shared_name" : "sweet (interacts with) RHCPScarTis",
        "shared_interaction" : "interacts with",
        "name" : "sweet (interacts with) RHCPScarTis",
        "interaction" : "interacts with",
        "SUID" : 277,
        "BEND_MAP_ID" : 277,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "272",
        "source" : "269",
        "target" : "236",
        "EdgeBetweenness" : 1.0,
        "shared_name" : "broken (interacts with) RHCPScarTis",
        "shared_interaction" : "interacts with",
        "name" : "broken (interacts with) RHCPScarTis",
        "interaction" : "interacts with",
        "SUID" : 272,
        "BEND_MAP_ID" : 272,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "263",
        "source" : "260",
        "target" : "236",
        "EdgeBetweenness" : 5.0,
        "shared_name" : "scarlet (interacts with) RHCPScarTis",
        "shared_interaction" : "interacts with",
        "name" : "scarlet (interacts with) RHCPScarTis",
        "interaction" : "interacts with",
        "SUID" : 263,
        "BEND_MAP_ID" : 263,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "258",
        "source" : "255",
        "target" : "236",
        "EdgeBetweenness" : 8.0,
        "shared_name" : "southern (interacts with) RHCPScarTis",
        "shared_interaction" : "interacts with",
        "name" : "southern (interacts with) RHCPScarTis",
        "interaction" : "interacts with",
        "SUID" : 258,
        "BEND_MAP_ID" : 258,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "296",
        "source" : "242",
        "target" : "236",
        "EdgeBetweenness" : 7.0,
        "shared_name" : "lonely (interacts with) RHCPScarTis",
        "shared_interaction" : "interacts with",
        "name" : "lonely (interacts with) RHCPScarTis",
        "interaction" : "interacts with",
        "SUID" : 296,
        "BEND_MAP_ID" : 296,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "294",
        "source" : "242",
        "target" : "236",
        "EdgeBetweenness" : 7.0,
        "shared_name" : "lonely (interacts with) RHCPScarTis",
        "shared_interaction" : "interacts with",
        "name" : "lonely (interacts with) RHCPScarTis",
        "interaction" : "interacts with",
        "SUID" : 294,
        "BEND_MAP_ID" : 294,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "292",
        "source" : "242",
        "target" : "236",
        "EdgeBetweenness" : 7.0,
        "shared_name" : "lonely (interacts with) RHCPScarTis",
        "shared_interaction" : "interacts with",
        "name" : "lonely (interacts with) RHCPScarTis",
        "interaction" : "interacts with",
        "SUID" : 292,
        "BEND_MAP_ID" : 292,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "283",
        "source" : "242",
        "target" : "236",
        "EdgeBetweenness" : 7.0,
        "shared_name" : "lonely (interacts with) RHCPScarTis",
        "shared_interaction" : "interacts with",
        "name" : "lonely (interacts with) RHCPScarTis",
        "interaction" : "interacts with",
        "SUID" : 283,
        "BEND_MAP_ID" : 283,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "281",
        "source" : "242",
        "target" : "236",
        "EdgeBetweenness" : 7.0,
        "shared_name" : "lonely (interacts with) RHCPScarTis",
        "shared_interaction" : "interacts with",
        "name" : "lonely (interacts with) RHCPScarTis",
        "interaction" : "interacts with",
        "SUID" : 281,
        "BEND_MAP_ID" : 281,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "279",
        "source" : "242",
        "target" : "236",
        "EdgeBetweenness" : 7.0,
        "shared_name" : "lonely (interacts with) RHCPScarTis",
        "shared_interaction" : "interacts with",
        "name" : "lonely (interacts with) RHCPScarTis",
        "interaction" : "interacts with",
        "SUID" : 279,
        "BEND_MAP_ID" : 279,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "267",
        "source" : "242",
        "target" : "236",
        "EdgeBetweenness" : 7.0,
        "shared_name" : "lonely (interacts with) RHCPScarTis",
        "shared_interaction" : "interacts with",
        "name" : "lonely (interacts with) RHCPScarTis",
        "interaction" : "interacts with",
        "SUID" : 267,
        "BEND_MAP_ID" : 267,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "265",
        "source" : "242",
        "target" : "236",
        "EdgeBetweenness" : 7.0,
        "shared_name" : "lonely (interacts with) RHCPScarTis",
        "shared_interaction" : "interacts with",
        "name" : "lonely (interacts with) RHCPScarTis",
        "interaction" : "interacts with",
        "SUID" : 265,
        "BEND_MAP_ID" : 265,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "253",
        "source" : "242",
        "target" : "236",
        "EdgeBetweenness" : 7.0,
        "shared_name" : "lonely (interacts with) RHCPScarTis",
        "shared_interaction" : "interacts with",
        "name" : "lonely (interacts with) RHCPScarTis",
        "interaction" : "interacts with",
        "SUID" : 253,
        "BEND_MAP_ID" : 253,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "251",
        "source" : "242",
        "target" : "236",
        "EdgeBetweenness" : 7.0,
        "shared_name" : "lonely (interacts with) RHCPScarTis",
        "shared_interaction" : "interacts with",
        "name" : "lonely (interacts with) RHCPScarTis",
        "interaction" : "interacts with",
        "SUID" : 251,
        "BEND_MAP_ID" : 251,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "249",
        "source" : "242",
        "target" : "236",
        "EdgeBetweenness" : 7.0,
        "shared_name" : "lonely (interacts with) RHCPScarTis",
        "shared_interaction" : "interacts with",
        "name" : "lonely (interacts with) RHCPScarTis",
        "interaction" : "interacts with",
        "SUID" : 249,
        "BEND_MAP_ID" : 249,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "247",
        "source" : "242",
        "target" : "236",
        "EdgeBetweenness" : 7.0,
        "shared_name" : "lonely (interacts with) RHCPScarTis",
        "shared_interaction" : "interacts with",
        "name" : "lonely (interacts with) RHCPScarTis",
        "interaction" : "interacts with",
        "SUID" : 247,
        "BEND_MAP_ID" : 247,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "245",
        "source" : "242",
        "target" : "236",
        "EdgeBetweenness" : 7.0,
        "shared_name" : "lonely (interacts with) RHCPScarTis",
        "shared_interaction" : "interacts with",
        "name" : "lonely (interacts with) RHCPScarTis",
        "interaction" : "interacts with",
        "SUID" : 245,
        "BEND_MAP_ID" : 245,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "290",
        "source" : "234",
        "target" : "236",
        "EdgeBetweenness" : 4.0,
        "shared_name" : "sarcastic (interacts with) RHCPScarTis",
        "shared_interaction" : "interacts with",
        "name" : "sarcastic (interacts with) RHCPScarTis",
        "interaction" : "interacts with",
        "SUID" : 290,
        "BEND_MAP_ID" : 290,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "240",
        "source" : "234",
        "target" : "236",
        "EdgeBetweenness" : 4.0,
        "shared_name" : "sarcastic (interacts with) RHCPScarTis",
        "shared_interaction" : "interacts with",
        "name" : "sarcastic (interacts with) RHCPScarTis",
        "interaction" : "interacts with",
        "SUID" : 240,
        "BEND_MAP_ID" : 240,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "230",
        "source" : "227",
        "target" : "185",
        "EdgeBetweenness" : 8.0,
        "shared_name" : "free (interacts with) FFMonkeyWren",
        "shared_interaction" : "interacts with",
        "name" : "free (interacts with) FFMonkeyWren",
        "interaction" : "interacts with",
        "SUID" : 230,
        "BEND_MAP_ID" : 230,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "225",
        "source" : "222",
        "target" : "185",
        "EdgeBetweenness" : 1.0,
        "shared_name" : "single (interacts with) FFMonkeyWren",
        "shared_interaction" : "interacts with",
        "name" : "single (interacts with) FFMonkeyWren",
        "interaction" : "interacts with",
        "SUID" : 225,
        "BEND_MAP_ID" : 225,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "220",
        "source" : "217",
        "target" : "185",
        "EdgeBetweenness" : 3.0,
        "shared_name" : "more (interacts with) FFMonkeyWren",
        "shared_interaction" : "interacts with",
        "name" : "more (interacts with) FFMonkeyWren",
        "interaction" : "interacts with",
        "SUID" : 220,
        "BEND_MAP_ID" : 220,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "215",
        "source" : "212",
        "target" : "185",
        "EdgeBetweenness" : 7.0,
        "shared_name" : "last (interacts with) FFMonkeyWren",
        "shared_interaction" : "interacts with",
        "name" : "last (interacts with) FFMonkeyWren",
        "interaction" : "interacts with",
        "SUID" : 215,
        "BEND_MAP_ID" : 215,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "232",
        "source" : "205",
        "target" : "185",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "indecent (interacts with) FFMonkeyWren",
        "shared_interaction" : "interacts with",
        "name" : "indecent (interacts with) FFMonkeyWren",
        "interaction" : "interacts with",
        "SUID" : 232,
        "BEND_MAP_ID" : 232,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "210",
        "source" : "205",
        "target" : "185",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "indecent (interacts with) FFMonkeyWren",
        "shared_interaction" : "interacts with",
        "name" : "indecent (interacts with) FFMonkeyWren",
        "interaction" : "interacts with",
        "SUID" : 210,
        "BEND_MAP_ID" : 210,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "208",
        "source" : "205",
        "target" : "185",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "indecent (interacts with) FFMonkeyWren",
        "shared_interaction" : "interacts with",
        "name" : "indecent (interacts with) FFMonkeyWren",
        "interaction" : "interacts with",
        "SUID" : 208,
        "BEND_MAP_ID" : 208,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "203",
        "source" : "200",
        "target" : "185",
        "EdgeBetweenness" : 5.0,
        "shared_name" : "adolescent (interacts with) FFMonkeyWren",
        "shared_interaction" : "interacts with",
        "name" : "adolescent (interacts with) FFMonkeyWren",
        "interaction" : "interacts with",
        "SUID" : 203,
        "BEND_MAP_ID" : 203,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "198",
        "source" : "183",
        "target" : "185",
        "EdgeBetweenness" : 6.0,
        "shared_name" : "much (interacts with) FFMonkeyWren",
        "shared_interaction" : "interacts with",
        "name" : "much (interacts with) FFMonkeyWren",
        "interaction" : "interacts with",
        "SUID" : 198,
        "BEND_MAP_ID" : 198,
        "selected" : false
      },
      "selected" : false
    } ]
  }
}}